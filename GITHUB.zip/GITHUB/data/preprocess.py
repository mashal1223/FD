# F:\FD\data\preprocess.py

import pandas as pd
from sklearn.preprocessing import LabelEncoder

def preprocess_dataset(filepath):
    # Load dataset
    data = pd.read_csv(filepath)

    # Split data into Client 1 and Client 2 datasets
    split_index = len(data) // 2
    client1_data = data.iloc[:split_index, :]
    client2_data = data.iloc[split_index:, :]

    # Apply LabelEncoder to categorical columns
    encoders = {}
    for col in data.select_dtypes(include='object').columns:
        le = LabelEncoder()
        client1_data[col] = le.fit_transform(client1_data[col])
        client2_data[col] = le.transform(client2_data[col])
        encoders[col] = le

    # Return client datasets and encoders
    return client1_data, client2_data, encoders
