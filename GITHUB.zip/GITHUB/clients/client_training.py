# F:\FD\clients\client_training.py

from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

def train_client_model(data):
    # Split features and labels
    X = data.iloc[:, :-1]
    y = data.iloc[:, -1]

    # Split into training and testing data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize MLP model
    model = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=300, random_state=42)

    # Train the model
    model.fit(X_train, y_train)

    # Evaluate on test data
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)

    return model, accuracy
