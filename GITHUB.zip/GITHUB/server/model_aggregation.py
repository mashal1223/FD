import tensorflow as tf

def aggregate_models(models):
    """Aggregate client models by averaging their weights."""
    avg_weights = [tf.reduce_mean([model.get_weights()[i] for model in models], axis=0)
                   for i in range(len(models[0].get_weights()))]
    return avg_weights
